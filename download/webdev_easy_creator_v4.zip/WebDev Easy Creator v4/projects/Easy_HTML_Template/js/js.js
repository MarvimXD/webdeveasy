//by Victor Beserra


function color() {
    var change = document.getElementById("javascript-change-color");
    change.style.backgroundColor = "red";
}